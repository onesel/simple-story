body {
color: red;
}