<?php get_header(); ?>
<div id="wrapper">

<div id="content">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="single_post_box"><!-- post box starts -->
<h1><?php the_title(); ?></h1>

<div class="single_post_thumb"><!-- post thumb starts -->
<?php
if ( has_post_thumbnail() )
the_POST_THUMBNAIL();
?>
</div>
	
<div> <!-- single post content -->
<h6>Posted on <?php the_time('F jS, Y') ?></h6>
<?php the_content(); ?>
</div> <!-- end of single post content -->


<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
</div><!-- end of post box -->

<div id="next_prev_link">
<div id="prev_link"><?php previous_post_link(); ?></div>
<div id="next_link"><?php next_post_link(); ?></div>
</div> <!-- end of next and prev post -->

</div>
<div style="clear: both; text-align: center";>...</div>
</div>

<?php get_footer(); ?>