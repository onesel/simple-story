<?php get_header(); ?>
<div id="wrapper">
<div id="content">
<h1>Main Area</h1>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="post_box"><!-- post box starts -->


<div class="post_thumb"><!-- post thumb starts -->
<?php if ( has_post_thumbnail() ) {
	the_post_thumbnail();
} else {?>
<img src="<?php bloginfo('template_directory'); ?>/images/default-image.png" alt="<?php the_title(); ?>" />
<?php } ?>

</div><!-- end of post thumb -->
	
<div class="post_content"><!-- post content starts -->
<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<h6>Posted on <?php the_time('F jS, Y') ?></h6>
<?php echo substr(get_the_excerpt(), 0, 200); ?> <span>[...]</span><br />
<a href="<?php the_permalink(); ?>"><div class="more">Read More</div></a>
</div><!-- end of post content -->

</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
</div>
<div style="clear: both; text-align: center";>...</div>
</div>

<?php get_footer(); ?>