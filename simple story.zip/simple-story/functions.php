<?php
function ws_menu(){
register_nav_menu('primary','Top Navigation');
}
add_action('init','ws_menu');

function ws_footer_menu(){
register_nav_menu('footer','Footer Navigation');
}
add_action('init','ws_footer_menu');

add_theme_support('post-thumbnails');
?>