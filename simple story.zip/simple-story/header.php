<html>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<title><?php bloginfo('name'); ?> | <?php wp_title(); ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>?<?php echo(time()); ?>" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">

<?php wp_head(); ?>
</head>
<body>

<div id="header">

<div>
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
  <div>
    <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
    <input type="submit" id="searchsubmit" value="Search" />
  </div>
</form>
</div>

<div id="logo">
<h2><a href="<?php echo get_site_url(); ?>"><?php bloginfo('name'); ?></a></h2>
<h4><?php bloginfo('description'); ?></h4>
</div><!-- end of logo -->

</div>

<div id="menu">
<?php wp_nav_menu(array('theme_location'=>'primary')); ?>
</div><!-- end of menu -->