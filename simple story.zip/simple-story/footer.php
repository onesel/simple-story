<div id="footer">

<div class="menu2">
<?php wp_nav_menu(array('theme_location'=>'footer')); ?>
</div>

<div class="credit">
&copy; <?php echo esc_html( bloginfo( 'name' ) );
            echo esc_html( date(" Y") ); ?> All Right Reserved

			
<div><?php _e( 'Zen theme by ', 'Morish' ); ?><a href="<?php echo esc_url( 'http://webeter.wall-spot.com' ); ?>">webeter</a>
</div>
</div>

</div>
<?php wp_footer(); ?>
</body>
</html>