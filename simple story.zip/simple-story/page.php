<?php get_header(); ?>
<div id="wrapper">
<div id="content">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="single_post_box"><!-- single page box starts -->
<h1><?php the_title(); ?></h1>

<div class="single_page_content">	
<h6>Posted on <?php the_time('F jS, Y') ?></h6>
<?php the_content(); ?>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
</div><!-- end of single page box -->

</div>
<div style="clear: both; text-align: center";>...</div>
</div>

<?php get_footer(); ?>